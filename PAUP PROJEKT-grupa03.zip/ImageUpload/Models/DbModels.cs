﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using ImageUpload.Models;
using MySql.Data.EntityFramework;


namespace Uploadimage.Models
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class DbModels : DbContext
    {
        public DbSet<Image> Images { get; set; }
        public DbSet<User> Korisnik { get; set; }
    }
}