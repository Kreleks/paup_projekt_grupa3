﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImageUpload.Models
{
    public class User
    {
        public int UserID { get; set; }
        [Required(ErrorMessage = "Korisnicki identitet je potreban.")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Korisnicko ime je potrebno.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [DataType(DataType.Password)]
        [DisplayName("Potvrdi lozinku")]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
        public bool Admin { get; set; }

        public string LoginErrorMessage { get; set; }
    }

    public class Login
    {
        [Required]
        [Display(Name = "Username")]
        public string Username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }
}