﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using Uploadimage.Models;


namespace Uploadimage.Models
{
    public class Image
    {
        public int ImageID { get; set; }

        public string Title { get; set; }
        [DisplayName("Upload photo")]
        //public string Description { get; set; }
        //[DisplayName("Upload photo")]
        public string ImagePath { get; set; }

        public string Description { get; set; }
        [DisplayName("Opis fotografije")]

        [NotMapped]
        public HttpPostedFileBase ImageFile { get; set; }
    }
}