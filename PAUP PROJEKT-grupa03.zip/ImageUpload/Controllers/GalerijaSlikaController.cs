﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Uploadimage.Models;

namespace ImageUpload.Controllers
{
    public class GalerijaSlikaController : Controller
    {
        // GET: GalerijaSlika
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult Galerija()
        {
            List<Image> all = new List<Image>();
            using (DbModels dc = new DbModels())
            {
                all = dc.Images.ToList();

            }

            return View(all);
        }

        public ActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Upload(DbModels ai)
        {

            using (DbModels dc = new DbModels())
            {
                ai.SaveChanges();
            }



                return RedirectToAction("Galerija");
            }

        }

    }
